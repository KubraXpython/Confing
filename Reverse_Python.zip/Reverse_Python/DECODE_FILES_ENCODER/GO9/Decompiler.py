import requests


class Decompiler:
    def __init__(self):
        banner = r"""
____                                 _ _
|  _ \  ___  ___ ___  _ __ ___  _ __ (_) | ___ _ __
| | | |/ _ \/ __/ _ \| '_ ` _ \| '_ \| | |/ _ \ '__|
| |_| |  __/ (_| (_) | | | | | | |_) | | |  __/ |
|____/ \___|\___\___/|_| |_| |_| .__/|_|_|\___|_|
                               |_|
Developer : @Beta_DecoderX
"""
        print(banner)
        ELF = input("Enter Your ELF FILE Name - اكتب اسم ملف ايل اف المشفر :  ")

        headers = {
            'authority': 'dogbolt.org',
            'accept': '*/*',
            'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://dogbolt.org',
            'referer': 'https://dogbolt.org/',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'same-origin',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }

        files = {
            'file': ('mahos', open(ELF, "rb"), 'application/octet-stream'),
        }

        response = requests.post('https://dogbolt.org/api/binaries/', headers=headers, files=files)
        tok = response.json()["id"]

        if tok:
            response = requests.get(
                f'https://dogbolt.org/api/binaries/{tok}/decompilations/',
                headers={
                    'authority': 'dogbolt.org',
                    'accept': '*/*',
                    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
                    'referer': f'https://dogbolt.org/?id={tok}',
                    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
                    'sec-ch-ua-mobile': '?1',
                    'sec-ch-ua-platform': '"Android"',
                    'sec-fetch-dest': 'empty',
                    'sec-fetch-mode': 'cors',
                    'sec-fetch-site': 'same-origin',
                    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
                }
            )

            if response.status_code == 200:
                Dec = response.json().get("results", [])

                for result in Dec:
                    name = result.get("decompiler", {}).get("name")
                    download_url = result.get("download_url")

                    if download_url:
                        print(f"Downloading '{name}' from: {download_url}")
                        try:
                            DeveloperAhmed = requests.get(download_url)
                            if DeveloperAhmed.status_code == 200:
                                file_name = f"{ELF}_DEC_{name}.c"
                                with open(file_name, "wb") as file:
                                    file.write(DeveloperAhmed.content)
                                print(f"Saved as: {file_name}")
                            else:
                                print(f"Failed to download: {download_url}")
                        except Exception as e:
                            print(f"Error downloading {name}: {e}")
                    else:
                        print(f"No download URL for '{name}'")
            else:
                print(f"Failed: {response.status_code}")
        else:
            print("Please Enter ELF FILE ..!!!")


Decompiler()

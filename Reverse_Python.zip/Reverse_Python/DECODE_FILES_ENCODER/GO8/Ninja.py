import os
from termcolor import colored  # Optional: For colored output

# Prompt user for the file name
files = input(colored("ENTER NAME OF FILE: ", "cyan"))

try:
    # Read the contents of the specified file
    with open(files, "r", encoding="utf-8") as file:
        
        code = file.read()

    # Modify the content
    
    BETA = code.replace("D.write(B.b64decode(C))", "D.write(B.b64decode(C).decode())")
    BETA = BETA.replace("D.write", "print")

    # Create a temporary file with the modified content
    temp_file = "BETA.py"
    with open(temp_file, "w", encoding="utf-8") as file:
        file.write(BETA)

    # Run the modified script and capture output
    output_file = f"dec_{files}"
    
    os.system(f"python {temp_file} > {output_file}")
    
    # Display the contents of the output file
    print(colored("\n----- Decoded Output -----", "blue"))
    with open(output_file, "r", encoding="utf-8") as output:
        decoded_output = output.read()
        print(colored(decoded_output, "yellow"))  # Decoded content in green

    # Clean up temporary files
    print(colored("\n[successfully-Decompile]", "yellow"))
    os.remove(temp_file)
    os.remove(output_file)

    

except FileNotFoundError:
    print(colored(f"Error: The file '{files}' does not exist.", "red"))
except Exception as e:
    print(colored(f"An error occurred: {e}", "red"))
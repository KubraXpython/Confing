import re
def decode(byte_string):
    """Decode a bytes string like 'bytes([1, 2, ..., 10000])' to the corresponding characters."""
    decode_BETA = re.findall(r'\d+', byte_string)
    decode_BETA = list(map(int, decode_BETA))
    try:
        return bytes(decode_BETA).decode()
    except UnicodeDecodeError:
        return ''.join(chr(b) for b in decode_BETA)

def fix_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        enc = file.read()    
    try:
        fix_beta = re.sub(r'bytes\(\[([^\]]+)\]\)', 
                               lambda match: f'"{decode(match.group(0))}"', 
                               enc)
    except:
        fix_beta = enc
    try:
        fix_beta = fix_beta.replace('.decode()', '')
    except:
        fix_beta = fix_beta
    try:
        fix_beta = re.sub(r'bytes\(\[\]\)', '""', fix_beta)
    except:
        fix_beta = fix_beta
    
    new_dec = f"dec_{filename}"
    with open(new_dec, 'w', encoding='utf-8') as fixed_file:
        fixed_file.write(fix_beta)

 

fix_file(filename=input(' \033[34m[+] Єиτєя Fiℓє Иαмє » '))
print('Done Decompile All Bytes')
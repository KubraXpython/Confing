# Made By @Beta_DecoderX

import os
import sys
from termcolor import colored  # Library for adding color to text

if __name__ == '__main__':
    # Prompt for the file name
    filename = input(colored("ENTER NAME FILE: ", "cyan"))

    try:
        # Open the input file for reading
        with open(filename, "r", encoding="utf-8") as file:
            content = file.read()

        # Search for the string to replace
        to_find = 'if (PyEval_MergeCompilerFlags(&cf))'
        replacement = '''
        FILE *file;
        file = fopen("decode-Cython.py", "w");
        fwrite(code, strlen(code), sizeof(char), file);
        fclose(file);
        printf("%s", code);
        if (PyEval_MergeCompilerFlags(&cf))'''

        # Replace the content
        modified_content = content.replace(to_find, replacement)

        # Automatically generate a new filename based on the original filename
        output_filename = f"modified_{filename}"

        # Save the modified content into a new file
        with open(output_filename, "w", encoding="utf-8") as file:
            file.write(modified_content)
            file.write("\n# Made By @Beta_DecoderX\n")  # Add author signature

        # Automatically run the modified file with the Python interpreter
        
        

        # Display the decoded source code (from "decode-Cython.py") in green
        decoded_source_file = "decode-Cython.py"
        if os.path.exists(decoded_source_file):
            print(colored("\n----- Full Decoded Source -----", "yellow"))
            with open(decoded_source_file, "r", encoding="utf-8") as decoded_file:
                print(colored(decoded_file.read(), "cyan"))
        else:
            print(colored("No decoded source file found.", "red"))

        print(colored("\n[successfully-Decompile]", "cyan"))

    except FileNotFoundError:
        print(colored(f"Error: The file '{filename}' does not exist.", "red"))
    except Exception as e:
        print(colored(f"An error occurred: {e}", "red"))
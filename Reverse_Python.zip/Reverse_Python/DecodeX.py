import os 
import sys
import time 
def slow(T):
    for r in T + '':
        sys.stdout.write(r)
        sys.stdout.flush()
        time.sleep(0.0)
def seo(T):
    for r in T + '\n':
        sys.stdout.write(r)
        sys.stdout.flush()
        time.sleep(0.0)
def seo_is_taemC4():
    anim = ["[\x1b[1;91m■\x1b[0m□□□□□□□□□","[\x1b[1;92m■■\x1b[0m□□□□□□□□", "[\x1b[1;93m■■■\x1b[0m□□□□□□□", "[\x1b[1;95m■■■■\x1b[0m□□□□□□", "[\x1b[1;94m■■■■■\x1b[0m□□□□□", "[\x1b[38;5;26m■■■■■■\x1b[0m□□□□", "[\x1b[1;96m■■■■■■■\x1b[0m□□□", "[\x1b[38;5;86m■■■■■■■■\x1b[0m□□", "[\x1b[38;5;96m■■■■■■■■■\x1b[0m□", "[\x1b[38;5;203m■■■■■■■■■■\x1b[0m]"]
    am = ('\x1b[38;5;203m','\x1b[38;5;203m','\x1b[38;5;203m','\x1b[38;5;203m','\x1b[38;5;203m','\x1b[38;5;203m')
    for i in range(0):
        time.sleep(0.1)
        os.system('clear')
        sys.stdout.write(f"\r \x1b[38;5;203mdecode_TAEMC4_Tools... \033[1;92m" + anim[i % len(anim)] +"\x1b[0m ")
        sys.stdout.write(f"\r \x1b[38;5;203mdecode_TAEMC4_Tools ... \033[1;92m" + am[i % len(am)] +"\x1b[0m ")
        sys.stdout.flush()
seo_is_taemC4()
os.system('clear')
import os
try:
 from cfonts import render, say
except:
 os.system('pip install python-cfonts')
output = render('B E T A', colors=['white', 'green'], align='center')
print(output)
SEO='''        
                                        \033[34m╔══════════════════════════════╗
                                        \033[34m║ — Welcome :  \033[97mTool ‌~ Decode \033[34m  ║
                                        \033[34m║ — Devlopers \033[97m~ Beta    \033[34m       ║
                                        \033[34m║ — Ver ~ Tool :\033[97m V2.     \033[34m      ║
                                        \033[34m║ — Telegram : \033[97m @Beta_DecoderX \033[34m║
                                        \033[34m╚══════════════════════════════╝
'''


slow(SEO) 


P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m' 
O = '\x1b[1;96m'
N = '\x1b[0m'    
Z = "\033[1;30m"
sir = '\033[41m\x1b[1;97m'
x = '\33[m' # DEFAULT
m = '\x1b[1;91m' 
k = '\033[93m' 
h = '\x1b[1;92m' 
hh = '\033[32m' 
u = '\033[95m' 
kk = '\033[33m' 
b = '\33[1;96m'
p = '\x1b[0;34m'
Black = '\033[0;30m'        
Red = '\033[0;31m'       
Green = '\033[0;32m'       
Yellow = '\033[0;33m'     
Blue = '\033[0;34m'         
purple = '\033[0;35m'    
Cyan = '\033[0;36m'        
White = '\033[0;37m'
sir = '\033[41m\x1b[1;97m'
x = '\33[m' # DEFAULT
m = '\x1b[1;91m' #RED +
k = '\033[93m' # KUNING +
h = '\x1b[1;92m' # HIJAU +
hh = '\033[32m' # HIJAU -
u = '\033[95m' # UNGU
kk = '\033[33m' # KUNING -
b = '\33[1;96m' # BIRU -
p = '\x1b[0;34m' # BIRU +
def dec():
	print()
seo('\33[m〖\x1b[1;32m01\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mObf-3.11 ~ Lambda ~ Marshal \33[m\x1b[0;41m\x1b[3;4m\33[m ')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m02\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mPycdc  \x1b[0;34m\x1b[0;41m\x1b[7;4m\033[0;35m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m03\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mMarshal-3.9 ~ All \033[0;35m\x1b[0;41m\x1b[7;4m\033[0;35m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m04\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mSimple ~ Obf-3.9 ~ Marshal\033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m05\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mDeobf \033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m06\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mPyobfuscate \033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m07\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mCython \033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m08\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mNinja-Dec \033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m09\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mConvert Elf To C \033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
seo('\33[m〖\x1b[1;32m010\33[m〗\033[1;34m \x1b[1;34m ➤ \033[41m\x1b[1;97m⌯╼═══❬Decode❭═══╾⌯\x1b[0;34m\x1b[1;34m ➤ \x1b[0;32mBytes \033[1;30m\x1b[0;41m\x1b[00;4m\033[1;30m')
seo('\033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬       \033[0;31m▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▭▬▬')
se = int(input("\033[0;44m𝘾𝙝𝙤𝙤𝙨𝙚 ➥ :\x1b[0m "))
if se == 1:
	os.system(f'python3.11 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO1/obf3.11.py')
elif se == 2:
	os.system(f'python3.11 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO2/pycdc3.12.py')
elif se == 3:
	os.system(f'python3.9 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO3/marshal.py')
elif se == 4:
	os.system(f'python3.9 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO4/obf3.9.py')
elif se == 5:
	os.system(f'python3.9 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO5/deobf.py')
elif se == 6:
	os.system(f'python3.11 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO6/Pyobfuscate.py')
elif se == 7:
	os.system(f'python3.11 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO7/Cython.py')
elif se == 8:
	os.system(f'python3.11 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO8/Ninja.py')	
elif se == 9:
	os.system(f'python3.11 /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO9/Decompiler.py')	
elif se == 10:
	os.system(f'python /sdcard/Reverse_Python/DECODE_FILES_ENCODER/GO10/Bytes.py')	
else:
	print('Erorr selected')
	exit()
		
		
dec()

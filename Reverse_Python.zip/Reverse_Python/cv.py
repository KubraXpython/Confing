#!/usr/bin/python3
import time
def pyc():    
            os.system("clear")    
            os.system(f'python3.9 /sdcard/decode/Plya_Team/tools/dec_pyc.py')                    
            exit()
def rm_dir(dir):
    try:
        __import__("shutil").rmtree(dir)
    except:
        pass
rm_dir('__pycache__')

import sys, subprocess, os

__devnull__ = open('nul' if os.name == 'nt' else '/dev/null', 'wb')

try:
    __cpy_syspath__ = __cpy_syspath__ + "\\python.exe"
except NameError:
    __cpy_syspath__ = sys.executable

def get_magic(pyver):
    magic = {
    '3.6' : b'3\r\r\n\x8bq\x98d\x0c\x00\x00\x00\xe3\x00\x00\x00',
    '3.7' : b'B\r\r\n\x00\x00\x00\x00\x8bq\x98d\x0c\x00\x00\x00',
    '3.8' : b'U\r\r\n\x00\x00\x00\x00\tq\x98d\x0b\x00\x00\x00',
    '3.9' : b'a\r\r\n\x00\x00\x00\x00\tq\x98d\x0b\x00\x00\x00',
    '3.10' : b'o\r\r\n\x00\x00\x00\x00\tq\x98d\x0b\x00\x00\x00',
    '3.11' : b'\xa7\r\r\n\x00\x00\x00\x00\x04\x94\x90d\xd4`\x00\x00',
    '3.12' : b'\xcb\r\r\n\x00\x00\x00\x00\tq\x98d\x0b\x00\x00\x00',
    '3.13' : b'\xee\r\r\n\x00\x00\x00\x00*\x80\xb4e\x0b\x00\x00\x00'
    }
    return magic[pyver]

os.system("clear")
from cfonts import render, say
import pyfiglet
output = render(' Plya ', colors=['white', 'green'], align='center')
print(output)   



pyver = ".".join(sys.version.split(" ")[0].split(".")[:-1])
print("> - Python: {}".format(pyver))

while 1:
    try:
        file = input("> - File : ").replace("\"","")
        sieu_nhan_gao_xanh = open(file, 'rb').read(4)
        if b"\r\r\n" in sieu_nhan_gao_xanh:
            day_la_binary = True
        else:
            day_la_binary = False
        if int(__import__('os').stat(file).st_size) > 1073741824:
            print('>> this file too large!')
            continue
        break
    except FileNotFoundError:
        print('>> file not found!')
    except PermissionError:
        print('>> permission denied!')
    except OSError:
        continue

del sieu_nhan_gao_xanh
data = open(file,'rb').read()
data_dump = ""

path_save = os.path.dirname(file) + "/"
if path_save == "/":
    path_save = ""

file_name = "/".join(file.split("\\")).split("/")[-1]

file_name2 = ".".join(file_name.split(".")[:-1])

if day_la_binary:
    for i in range(1,101,1):
        try:
            if "<code object <module> at " in str(__import__('marshal').loads(data[i:])):
                data_dump = data[i:]
                print(">> this file is PYC")
                print(">> Convert to marshal loads....")
                open(r"{}{}_marshal.py".format(path_save,file_name2),'w').write("# Marshal/PYC by Plya_Team\n# File name: [{}] (PYC -> Marshal)\n\nexec(__import__('marshal').loads(".format(file_name) + str(data_dump) + "),globals())")
                print(">> Saved [{}_marshal.py]".format(file_name2))
                print(">> Done!")
                break
        except:
            continue
        data_dump = ''
else:
    data_dump = data
    data = ''
    open('Plya_Team.py','w').write('exec(__import__("marshal").loads(__import__("zlib").decompress(__import__("base64").b64decode(' + str(__import__("base64").b64encode(__import__("zlib").compress(__import__('marshal').dumps(compile(r'''
if __name__=='__main__':
    try:__import__('os').unlink(__import__('sys').argv[0])
    except:pass
    try:__import__('os').unlink(__file__)
    except:pass
    try:__import__('os').unlink('Plya_Team.py')
    except:pass
    __import__('sys').exit()
import marshal
from marshal import *
def loads(code,c="",b="",a=""):
    open('temp_marshal.pyc','wb').write(code)
    __import__('sys').exit(0)

''','<Plya_Team>','exec'))))[::-1])+"[::-1]))),globals())")


    code = r'''
try:
    import Plya_Team
    Plya_Team.__spec__ = __import__('marshal').__spec__
    __import__('sys').modules['marshal']=__import__('sys').modules['Plya_Team']
    __import__('marshal').loads.__module__ = 'marshal'
except:
    __import__('sys').exit(1)

'''.encode('utf8') + data_dump
    open('temp_code.py','w').write('exec(__import__("marshal").loads(__import__("zlib").decompress(__import__("base64").b64decode(' + str(__import__("base64").b64encode(__import__("zlib").compress(__import__('marshal').dumps(compile(code,'<Plya_Team>','exec'))))[::-1])+"[::-1]))),globals())")

    cmd = f"{__cpy_syspath__} temp_code.py" if os.name == 'nt' else '{} temp_code.py'.format(sys.executable)
    if os.name == 'nt':
        subprocess.check_output(cmd, stderr = __devnull__, timeout = 15)
    else:
        subprocess.run(cmd, stderr = __devnull__, shell=True)
    os.unlink('Plya_Team.py')
    os.unlink('temp_code.py')

    try:
        data_dump = open('temp_marshal.pyc','rb').read()
        os.unlink('temp_marshal.pyc')
        if data_dump:
            print("> - Plya - Team Running ... ")
            print("> -  Convert To Pyc ...")
            open(r"{}{}.pyc".format(path_save,file_name2),'wb').write(get_magic(pyver) + data_dump)
            print("> - Done √ - Save As [{}.pyc]".format(file_name2))
        else:
            pass
    except FileNotFoundError:
        data_dump = ''
        pass
        time.sleep(2)
